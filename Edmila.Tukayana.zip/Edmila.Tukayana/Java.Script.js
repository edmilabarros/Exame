document.addEventListener("DOMContentLoaded", function() {
    // Adiciona a classe "visible" ao menu após um pequeno atraso
    setTimeout(function() {
        document.querySelector(".menu").classList.add("visible");
    }, 500); // Atraso de 500ms (0.5 segundos)
   
});
let next = document.querySelector('.next')
let prev = document.querySelector('.prev')

next.addEventListener('click', function(){
  let items = document.querySelectorAll('.item')
  document.querySelector('.slide').appendChild(items[0])
})

prev.addEventListener('click', function(){
  let items = document.querySelectorAll('.item')
  document.querySelector('.slide').prepend(items[items.length - 1])
})

let queue = []; // Fila global para armazenar os elementos

function enqueue() {
  const value = document.getElementById('queue-value').value;
  if (value) {
    queue.push(value); // Adiciona o valor à fila
    document.getElementById('queue-value').value = ''; // Limpa o campo de entrada
    drawQueue(); // Redesenha a fila com a animação
  }
}

function dequeue() {
  if (queue.length > 0) {
    queue.shift(); // Remove o primeiro elemento da fila
    drawQueue(); // Redesenha a fila com a animação
  }
}

function clearQueue() {
  queue = []; // Limpa a fila completamente
  drawQueue(); // Redesenha a fila com a animação
}

function drawQueue() {
  const svg = document.getElementById('queue-svg');
  svg.innerHTML = '';

  queue.forEach((item, index) => {
    const circle = document.createElementNS('http://www.w3.org/2000/svg', 'circle');
    circle.setAttribute('cx', 50 + index * 60);
    circle.setAttribute('cy', 50);
    circle.setAttribute('r', 20);
    circle.setAttribute('fill', 'lightblue');
    svg.appendChild(circle);

    const text = document.createElementNS('http://www.w3.org/2000/svg', 'text');
    text.setAttribute('x', 50 + index * 60);
    text.setAttribute('y', 55);
    text.setAttribute('text-anchor', 'middle');
    text.textContent = item;
    svg.appendChild(text);

    if (index > 0) {
      const line = document.createElementNS('http://www.w3.org/2000/svg', 'line');
      line.setAttribute('x1', 50 + (index - 1) * 60 + 20);
      line.setAttribute('y1', 50);
      line.setAttribute('x2', 50 + index * 60 - 20);
      line.setAttribute('y2', 50);
      line.setAttribute('stroke', 'black');
      line.setAttribute('marker-end', 'url(#arrow)');
      svg.appendChild(line);
    }
  });
}

// Função para iniciar a animação de mudança de cores
function startColorAnimation() {
  setInterval(animateColors, 1000); // Atualiza as cores a cada segundo
}

// Função para animar as cores das bolas na fila
function animateColors() {
  const svg = document.getElementById('queue-svg');
  queue.forEach((item, index) => {
    const hue = (index * 30) % 360; // Calcula a matiz com base no índice
    const circle = svg.children[index];
    circle.setAttribute('fill', `hsl(${hue}, 70%, 70%)`); // Aplica a nova cor
  });
}

// Exemplo de uso:
enqueue(); // Adiciona um item à fila
startColorAnimation(); // Inicia a animação de mudança de cores

class TreeNode {
    constructor(value) {
        this.value = value;
        this.left = null;
        this.right = null;
    }
}

class BinaryTree {
    constructor() {
        this.root = null;
    }

    insert(value) {
        const newNode = new TreeNode(value);
        if (this.root === null) {
            this.root = newNode;
        } else {
            this.insertNode(this.root, newNode);
        }
    }

    insertNode(node, newNode) {
        if (newNode.value < node.value) {
            if (node.left === null) {
                node.left = newNode;
            } else {
                this.insertNode(node.left, newNode);
            }
        } else {
            if (node.right === null) {
                node.right = newNode;
            } else {
                this.insertNode(node.right, newNode);
            }
        }
    }

    remove(value) {
        this.root = this.removeNode(this.root, value);
    }

    removeNode(node, key) {
        if (node === null) return null;

        if (key < node.value) {
            node.left = this.removeNode(node.left, key);
            return node;
        } else if (key > node.value) {
            node.right = this.removeNode(node.right, key);
            return node;
        } else {
            if (node.left === null && node.right === null) {
                node = null;
                return node;
            }

            if (node.left === null) {
                node = node.right;
                return node;
            } else if (node.right === null) {
                node = node.left;
                return node;
            }

            const aux = this.findMinNode(node.right);
            node.value = aux.value;
            node.right = this.removeNode(node.right, aux.value);
            return node;
        }
    }

    findMinNode(node) {
        if (node.left === null) return node;
        else return this.findMinNode(node.left);
    }

    search(node, value) {
        if (node === null) return null;
        else if (value < node.value) return this.search(node.left, value);
        else if (value > node.value) return this.search(node.right, value);
        else return node;
    }

    preorderTraversal(node, result = []) {
        if (node !== null) {
            result.push(node.value);
            this.preorderTraversal(node.left, result);
            this.preorderTraversal(node.right, result);
        }
        return result;
    }

    inorderTraversal(node, result = []) {
        if (node !== null) {
            this.inorderTraversal(node.left, result);
            result.push(node.value);
            this.inorderTraversal(node.right, result);
        }
        return result;
    }

    postorderTraversal(node, result = []) {
        if (node !== null) {
            this.postorderTraversal(node.left, result);
            this.postorderTraversal(node.right, result);
            result.push(node.value);
        }
        return result;
    }
    

    depth(node) {
        if (node === null) {
            return 0;
        } else {
            const leftDepth = this.depth(node.left);
            const rightDepth = this.depth(node.right);
            return Math.max(leftDepth, rightDepth) + 1;
        }
    }

    width(node) {
        if (node === null) return 0;
        
        let maxWidth = 0;
        const queue = []; // Utilizaremos uma fila para percorrer os níveis
        
        queue.push(node); // Iniciamos com o nó raiz na fila
        
        while (queue.length > 0) {
            const count = queue.length; // Contamos quantos nós há no nível atual
            
            // Atualizamos a largura máxima
            maxWidth = Math.max(maxWidth, count);
            
            // Percorremos todos os nós do nível atual e adicionamos seus filhos na fila
            for (let i = 0; i < count; i++) {
                const current = queue.shift(); // Removemos o primeiro nó da fila
                
                if (current.left !== null) queue.push(current.left);
                if (current.right !== null) queue.push(current.right);
            }
        }
        
        return maxWidth;
    }
    getWidth(node, level) {
        if (node === null) return 0;
        if (level === 0) return 1;
        else if (level > 0) {
            return this.getWidth(node.left, level - 1) + this.getWidth(node.right, level - 1);
        }
    }
}

// Inicialização da árvore binária
let binaryTree = new BinaryTree();

function insertNode() {
    const value = document.getElementById('tree-value').value;
    if (value !== '') {
        binaryTree.insert(parseInt(value));
        document.getElementById('tree-value').value = ''; // Limpa o campo de entrada após inserção
        drawTree(); // Redesenhar a árvore após a inserção
    }
}

function removeNode() {
    const value = document.getElementById('tree-value').value;
    if (value !== '') {
        binaryTree.remove(parseInt(value));
        document.getElementById('tree-value').value = ''; // Limpa o campo de entrada após remoção
        drawTree(); // Redesenhar a árvore após a remoção
    }
}

function findNode() {
    const value = document.getElementById('tree-value').value;
    if (value !== '') {
        const resultNode = binaryTree.search(binaryTree.root, parseInt(value));
        if (resultNode !== null) {
            alert(`Valor ${value} encontrado na árvore!`);
        } else {
            alert(`Valor ${value} não encontrado na árvore.`);
        }
    }
}

function traversePreorder() {
    const result = binaryTree.preorderTraversal(binaryTree.root);
    displayTraversalResult(result);
}

function traverseInorder() {
    const result = binaryTree.inorderTraversal(binaryTree.root);
    displayTraversalResult(result);
}

function traversePostorder() {
    const result = binaryTree.postorderTraversal(binaryTree.root);
    displayTraversalResult(result);
}

function calculateDepth() {
    const depth = binaryTree.depth(binaryTree.root);
    console.log(`Profundidade da árvore: ${depth}`);
    document.getElementById('tree-metrics').innerText = `Profundidade da árvore: ${depth}`;
}

function calculateWidth() {
    const width = binaryTree.width(binaryTree.root);
    console.log(`Largura da árvore: ${width}`);
    document.getElementById('tree-metrics').innerText = `Largura da árvore: ${width}`;
}
function displayTraversalResult(result) {
    const traversalResultDiv = document.getElementById('traversal-result');
    traversalResultDiv.innerHTML = '';
    result.forEach(value => {
        const nodeDiv = document.createElement('div');
        nodeDiv.textContent = value;
        traversalResultDiv.appendChild(nodeDiv);
    });
}

function drawTree() {
    const svg = document.getElementById('tree-svg');
    svg.innerHTML = '';
    if (binaryTree.root !== null) {
        drawNode(svg, binaryTree.root, 400, 30, 200);
    }
}

function drawNode(svg, node, x, y, dx) {
    if (node.left !== null) {
        drawLine(svg, x, y, x - dx, y + 50);
        drawNode(svg, node.left, x - dx, y + 50, dx / 2);
    }
    if (node.right !== null) {
        drawLine(svg, x, y, x + dx, y + 50);
        drawNode(svg, node.right, x + dx, y + 50, dx / 2);
    }
    drawCircle(svg, x, y, node.value);
}

function drawCircle(svg, x, y, value) {
    const circle = document.createElementNS('http://www.w3.org/2000/svg', 'circle');
    circle.setAttribute('cx', x);
    circle.setAttribute('cy', y);
    circle.setAttribute('r', 20);
    circle.setAttribute('stroke', 'black');
    circle.setAttribute('stroke-width', 2);
    circle.setAttribute('fill', 'white');
    svg.appendChild(circle);

    const text = document.createElementNS('http://www.w3.org/2000/svg', 'text');
    text.setAttribute('x', x);
    text.setAttribute('y', y + 5);
    text.setAttribute('text-anchor', 'middle');
    text.textContent = value;
    svg.appendChild(text);
}

function drawLine(svg, x1, y1, x2, y2) {
    const line = document.createElementNS('http://www.w3.org/2000/svg', 'line');
    line.setAttribute('x1', x1);
    line.setAttribute('y1', y1);
    line.setAttribute('x2', x2);
    line.setAttribute('y2', y2);
    line.setAttribute('stroke', 'black');
    svg.appendChild(line);
}


class Graph {
    constructor() {
        this.vertices = [];
        this.edges = new Map();
    }

    addVertex(vertex) {
        if (!this.vertices.includes(vertex)) {
            console.log('Adicionando vértice: ${vertex}');
            this.vertices.push(vertex);
            this.edges.set(vertex, []);
        } else {
            console.log('Vértice ${vertex} já existe');
        }
    }

    addEdge(v1, v2) {
        if (this.vertices.includes(v1) && this.vertices.includes(v2)) {
            console.log('Adicionando aresta de ${v1} a ${v2}');
            if (!this.edges.get(v1).includes(v2)) {
                this.edges.get(v1).push(v2);
            }
            if (!this.edges.get(v2).includes(v1)) {
                this.edges.get(v2).push(v1); // Para grafos não direcionados
            }
        } else {
            console.log('Um ou ambos os vértices ${v1}, ${v2} não existem');
        }
    }

    removeVertex(vertex) {
        const index = this.vertices.indexOf(vertex);
        if (index !== -1) {
            console.log('Removendo vértice: ${vertex}');
            this.vertices.splice(index, 1);
            this.edges.delete(vertex);
            for (let [key, value] of this.edges) {
                const edgeIndex = value.indexOf(vertex);
                if (edgeIndex !== -1) {
                    value.splice(edgeIndex, 1);
                }
            }
        } else {
            console.log('Vértice ${vertex} não encontrado');
        }
    }

    removeEdge(v1, v2) {
        if (this.vertices.includes(v1) && this.vertices.includes(v2)) {
            console.log('Removendo aresta de ${v1} a ${v2}');
            let index = this.edges.get(v1).indexOf(v2);
            if (index !== -1) this.edges.get(v1).splice(index, 1);

            index = this.edges.get(v2).indexOf(v1);
            if (index !== -1) this.edges.get(v2).splice(index, 1);
        } else {
            console.log('Um ou ambos os vértices ${v1}, ${v2} não existem');
        }
    }

    bfs(start) {
        const result = [];
        const visited = {};
        const queue = [start];

        while (queue.length > 0) {
            const vertex = queue.shift();
            if (!visited[vertex]) {
                visited[vertex] = true;
                result.push(vertex);
                queue.push(...this.edges.get(vertex));
            }
        }

        console.log('BFS Result: ${result}');
        return result;
    }

    dfs(start, visited = {}, result = []) {
        if (!visited[start]) {
            visited[start] = true;
            result.push(start);
            const neighbors = this.edges.get(start);
            for (let neighbor of neighbors) {
                this.dfs(neighbor, visited, result);
            }
        }

        console.log('DFS Result: ${result}');
        return result;
    }
}

// Inicialização do grafo
let graph = new Graph();

function addGraphVertex() {
    const vertex = document.getElementById('graph-vertex').value;
    console.log('Chamada para adicionar vértice: ${vertex}');
    if (vertex !== '') {
        graph.addVertex(vertex);
        drawGraph();
        document.getElementById('graph-vertex').value = '';
    }
}

function addGraphEdge() {
    const vertex1 = document.getElementById('graph-edge-v1').value;
    const vertex2 = document.getElementById('graph-edge-v2').value;
    console.log('Chamada para adicionar aresta: ${vertex1} - ${vertex2}');
    if (vertex1 !== '' && vertex2 !== '') {
        if (graph.vertices.includes(vertex1) && graph.vertices.includes(vertex2)) {
            graph.addEdge(vertex1, vertex2);
            drawGraph();
            document.getElementById('graph-edge-v1').value = '';
            document.getElementById('graph-edge-v2').value = '';
        } else {
            alert('Um ou ambos os vértices ${vertex1} e ${vertex2} não existem.');
        }
    }
}

function drawGraph() {
    console.log('Desenhando grafo');
    const svg = document.getElementById('graph-svg');
    svg.innerHTML = '';

    const drawVertex = (x, y, vertex) => {
        const circle = document.createElementNS('http://www.w3.org/2000/svg', 'circle');
        circle.setAttribute('cx', x);
        circle.setAttribute('cy', y);
        circle.setAttribute('r', 20);
        circle.setAttribute('fill', 'lightblue');
        svg.appendChild(circle);

        const text = document.createElementNS('http://www.w3.org/2000/svg', 'text');
        text.setAttribute('x', x);
        text.setAttribute('y', y + 5);
        text.setAttribute('text-anchor', 'middle');
        text.textContent = vertex;
        svg.appendChild(text);
    };

    const drawEdge = (x1, y1, x2, y2) => {
        const line = document.createElementNS('http://www.w3.org/2000/svg', 'line');
        line.setAttribute('x1', x1);
        line.setAttribute('y1', y1);
        line.setAttribute('x2', x2);
        line.setAttribute('y2', y2);
        line.setAttribute('stroke', 'black');
        svg.appendChild(line);
    };

    const vertexPositions = new Map();
    const radius = 200;
    const centerX = 400;
    const centerY = 300;

    graph.vertices.forEach((vertex, index) => {
        const angle = (index / graph.vertices.length) * 2 * Math.PI;
        const x = centerX + radius * Math.cos(angle);
        const y = centerY + radius * Math.sin(angle);
        vertexPositions.set(vertex, { x, y });
        drawVertex(x, y, vertex);
    });

    graph.edges.forEach((neighbors, vertex) => {
        neighbors.forEach(neighbor => {
            const { x: x1, y: y1 } = vertexPositions.get(vertex);
            const { x: x2, y: y2 } = vertexPositions.get(neighbor);
            drawEdge(x1, y1, x2, y2);
        });
    });
}